#ifndef GyverFilters_h
#define GyverFilters_h
#include <filters/alfaBeta.h>
#include <filters/kalman.h>
#include <filters/linear.h>
#include <filters/median.h>
#include <filters/median3.h>
#include <filters/runningAverage.h>
#include <filters/FastFilter.h>
#include <filters/RingAverage.h>

/*
	GyverFilters - библиотека с некоторыми удобными фильтрами.
	Документация: https://alexgyver.ru/gyverfilters/
	- GFilterRA - компактная альтернатива фильтра экспоненциальное бегущее среднее (Running Average)			
	- GMedian3 - быстрый медианный фильтр 3-го порядка (отсекает выбросы)
	- GMedian - медианный фильтр N-го порядка. Порядок настраивается в GyverFilters.h - MEDIAN_FILTER_SIZE
	- GABfilter - альфа-бета фильтр (разновидность Калмана для одномерного случая)
	- GKalman - упрощённый Калман для одномерного случая (на мой взгляд лучший из фильтров)
	- GLinear - линейная аппроксимация методом наименьших квадратов для двух массивов
	
	Версии
	- 1.6 от 12.11.2019
	- 1.7: исправлен GLinear
	- 1.8: небольшие улучшения
	- 2.0:
		- Улучшен и исправлен median и median3
		- Улучшен linear
		- Смотрите примеры! Использование этих фильтров чуть изменилось
	- 2.1: Исправлен расчёт дельты в линейном фильтре
	- 2.2: Исправлена ошибка компиляции
	- 3.0: Добавлен FastFilter и RingAverage
*/
#endif